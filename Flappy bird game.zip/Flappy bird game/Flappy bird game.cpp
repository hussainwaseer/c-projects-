#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cstdlib>
#include <ctime>

using namespace std;

// Game settings
const int width = 30;
const int height = 10;
const char helicopter = int(1);
const char pipe = '#';
const char space = ' ';

// Game state
int helicopterY = height / 2;
int pipeX = width - 1;
int gapY;
int score = 0;
bool gameOver = false;

// Function to setup the game
void Setup() {
    srand(time(0));
    gapY = rand() % (height - 3) + 1;  // Random gap between 1 and height-3
}

// Function to draw the game state
void Draw() {
    system("cls");  // Clear the screen

    // Draw the top border
    for (int i = 0; i < width; i++) cout << "#";
    cout << endl;

    // Draw the game area
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            if (x == 0 || x == width - 1) { // Borders
                cout << "#";
            } else if (x == 5 && y == helicopterY) { // Helicopter position
                cout << helicopter;
            } else if (x == pipeX && (y < gapY || y > gapY + 2)) { // Pipe positions (gap for the helicopter)
                cout << pipe;
            } else {
                cout << space;
            }
        }
        cout << endl;
    }

    // Draw the bottom border
    for (int i = 0; i < width; i++) cout << "#";
    cout << endl;

    // Display score
    cout << "Score: " << score << endl;
}

// Function to handle input
void Input() {
    if (_kbhit()) {
        char ch = _getch();
        if (ch == 'w') {  // Move helicopter up
            helicopterY--;
        } else if (ch == 's') {  // Move helicopter down
            helicopterY++;
        } else if (ch == 'x') {  // Exit the game
            gameOver = true;
        }
    }
}

// Function to update the game logic
void Logic() {
    // Move the pipe to the left
    pipeX--;

    // If the pipe goes out of screen, reset it
    if (pipeX < 1) {
        pipeX = width - 1;
        gapY = rand() % (height - 3) + 1;  // Generate a new gap
        score++;  // Increase score when the pipe passes
    }

    // Check for collisions (helicopter is in pipe area)
    if ((pipeX == 5) && (helicopterY < gapY || helicopterY > gapY + 2)) {
        gameOver = true;  // Collided with the pipe
    }

    // Prevent the helicopter from going out of bounds
    if (helicopterY < 0) helicopterY = 0;
    if (helicopterY >= height) helicopterY = height - 1;
}

// Function to add a delay (controls game speed)
void SleepMs(int ms) {
    Sleep(ms);  // Sleep for a specified time (milliseconds)
}

// Main function to run the game
int main() {
    Setup();

    while (!gameOver) {
        Draw();
        Input();
        Logic();
        SleepMs(100);  // Control the speed of the game loop
    }

    cout << "Game Over! Final Score: " << score << endl;
    system("PAUSE");
    return 0;
}

