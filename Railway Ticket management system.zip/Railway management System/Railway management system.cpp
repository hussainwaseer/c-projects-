#include<iostream>
#include<vector>
#include<windows.h>
#include<unistd.h>
#include<fstream>
#include<sstream>
using namespace std;

void Welcome(){
    cout << "*******************************\n";
    cout << " Railway Ticket Booking System\n";
    cout << "*******************************\n";
}

void ADD(){
    Welcome();
    ofstream add("Tickets.txt", ios::app);
    cout << "Enter the Train Name: ";
    string train_name;
    cin.ignore();
    getline(cin, train_name);
    cout << "Enter the Available Seats: ";
    int available_seats;
    cin >> available_seats;
    cout << "Enter the Ticket Price: ";
    int price;
    cin >> price;
    add << train_name << "*" << available_seats << "*" << price << endl;
    cout << "Ticket Added Successfully\n";
    add.close();
    system("PAUSE");
    system("CLS");
}

void SEARCH(){
    ifstream search("Tickets.txt");
    cout << "Enter the Train Name: ";
    string train_name;
    cin.ignore();
    getline(cin, train_name);
    string getdata;
    bool checker = false;
    while (getline(search, getdata)) {
        istringstream gdata(getdata);
        string name, seats, price;
        getline(gdata, name, '*');
        getline(gdata, seats, '*');
        getline(gdata, price);
        if (name == train_name) {
            system("CLS");
            Welcome();
            cout << "Train Name\t\tAvailable Seats\t\tTicket Price\n";
            cout << name << "\t\t" << seats << "\t\t\t" << price << endl;
            checker = true;
            system("PAUSE");
            break;
        }
    }
    if (checker == false) {
        cout << "Oops! Train not found. Try again.\n";
        sleep(1);
        system("CLS");
        SEARCH();
    }
    system("CLS");
}

void SHOWALL(){
    ifstream show("Tickets.txt");
    Welcome();
    cout << "Train Name\t\tAvailable Seats\t\tTicket Price\n";
    string getdata;
    while (getline(show, getdata)) {
        istringstream gdata(getdata);
        string name, seats, price;
        getline(gdata, name, '*');
        getline(gdata, seats, '*');
        getline(gdata, price);
        cout << name << "\t\t" << seats << "\t\t\t" << price << endl;
    }
    system("PAUSE");
    system("CLS");
}

void Delete(){
    system("CLS");
    Welcome();
    ifstream read("Tickets.txt");
    cout << "Enter the Train Name you want to delete: ";
    string deltrain;
    cin.ignore();
    getline(cin, deltrain);
    bool found = false;
    vector<string> name;
    vector<string> seats;
    vector<string> price;
    string getticket;
    while (getline(read, getticket)) {
        istringstream taketicket(getticket);
        string token;
        getline(taketicket, token, '*');
        name.push_back(token);
        getline(taketicket, token, '*');
        seats.push_back(token);
        getline(taketicket, token, '*');
        price.push_back(token);
    }
    for (int i = 0; i < name.size(); i++) {
        if (deltrain == name[i]) {
            found = true;
            cout << "Train found!\n";
            cout << "Deleting the train record\n";
            name.erase(name.begin() + i);
            seats.erase(seats.begin() + i);
            price.erase(price.begin() + i);
            ofstream newwrite("Tickets.txt");
            for (int i = 0; i < name.size(); i++) {
                newwrite << name[i] << "*" << seats[i] << "*" << price[i] << endl;
            }
            newwrite.close();
        }
    }
    if (found == false) {
        cout << "Oops! Train not found!\n";
        cout << "Try again\n";
        system("PAUSE");
        Delete();
    }
    cout << "Deleted successfully\n";
    system("PAUSE");
    system("CLS");
}

int main(){
    int choice;
    do {
        Welcome();
        cout << "1. Add Train Ticket\n";
        cout << "2. Search for Train Ticket\n";
        cout << "3. Show All Train Tickets\n";
        cout << "4. Delete Train Ticket\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                system("CLS");
                ADD();
                break;
            case 2:
                system("CLS");
                SEARCH();
                break;
            case 3:
                system("CLS");
                SHOWALL();
                break;
            case 4:
                Delete();
                break;
        }
    }
    while (choice != 5);
    return 0;
}

