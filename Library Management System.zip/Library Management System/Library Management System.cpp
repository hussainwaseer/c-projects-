#include <iostream>
#include <fstream>
#include <string>
using namespace std;

const int MAX_BOOKS = 50;

struct Book {
    string title;
    string author;
    bool Available;
};

Book library[MAX_BOOKS];
int bookCount = 0;

void loadBooks() {
    ifstream inputFile("library.txt");
    if (!inputFile) {
        return;
    }
    
    string title, author;
    bool available;
    while (getline(inputFile, title)) {
        getline(inputFile, author);
        inputFile >> available;
        inputFile.ignore();

        if (bookCount < MAX_BOOKS) {
            library[bookCount].title = title;
            library[bookCount].author = author;
            library[bookCount].Available = available;
            bookCount++;
        }
    }
    inputFile.close();
}

void saveBooks() {
    ofstream outputFile("library.txt",ios::app);
    for (int i = 0; i < bookCount; i++) {
        outputFile << library[i].title << endl;
        outputFile << library[i].author << endl;
        outputFile << library[i].Available << endl;
    }
    outputFile.close();
}

void addBook(const string& title, const string& author) {
    if (bookCount < MAX_BOOKS) {
        library[bookCount].title = title;
        library[bookCount].author = author;
        library[bookCount].Available = true;
        bookCount++;
        saveBooks();
    } else {
        cout << "Library is full. Cannot add more books." << endl;
    }
}

void displayBooks() {
    cout << "\nAvailable Books:\n";
    for (int i = 0; i < bookCount; i++) {
        cout << "Title: " << library[i].title << ", Author: " << library[i].author
             << (library[i].Available ? " (Available)" : " (Borrowed)") << endl;
    }
}

void borrowBook(const string& title) {
    for (int i = 0; i < bookCount; i++) {
        if (library[i].title == title) {
            if (library[i].Available) {
                library[i].Available = false;
                cout << "You have borrowed: " << title << endl;
                saveBooks();
            } else {
                cout << "Sorry, this book is already borrowed." << endl;
            }
            return;
        }
    }
    cout << "Book not found." << endl;
}

void returnBook(const string& title) {
    for (int i = 0; i < bookCount; i++) {
        if (library[i].title == title) {
            if (!library[i].Available) {
                library[i].Available = true;
                cout << "You have returned: " << title << endl;
                saveBooks();
            } else {
                cout << "This book was not borrowed." << endl;
            }
            return;
        }
    }
    cout << "Book not found." << endl;
}

int main() {
    int choice;
    string title, author;

    loadBooks();

    do {
        cout << "\nLibrary Management System\n";
        cout << "1. Add Book\n";
        cout << "2. Display Books\n";
        cout << "3. Borrow Book\n";
        cout << "4. Return Book\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter book title: ";
                cin.ignore(); 
                getline(cin, title);
                cout << "Enter book author: ";
                getline(cin, author);
                addBook(title, author);
                break;
            case 2:
                displayBooks();
                break;
            case 3:
                cout << "Enter book title to borrow: ";
                cin.ignore();
                getline(cin, title);
                borrowBook(title);
                break;
            case 4:
                cout << "Enter book title to return: ";
                cin.ignore();
                getline(cin, title);
                returnBook(title);
                break;
            case 5:
                cout << "Exiting the system." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 5);

    return 0;
}

