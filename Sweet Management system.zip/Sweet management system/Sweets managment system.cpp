#include<iostream>
#include<unistd.h>
#include<vector>
#include<windows.h>
#include<fstream>
#include<sstream>
using namespace std;
void Welcome(){
	cout<<"*******************************\n";
	cout<<" Sweet Management System\n";
	cout<<"*******************************\n";
}
void ADD(){
	Welcome();
	ofstream add("Sweet.txt", ios::app);
	cout<<"Enter the name of Sweet: ";
	string name;
	cin.ignore();
	getline(cin, name);
	cout<<"Enter the Quantity of Sweet: ";
	int quantity;
	cin>>quantity;
	cout<<"Enter the price of Sweet: ";
	int price;
	cin>>price;
	add<<name<<"*"<<quantity<<"*"<<price<<endl;
	cout<<"Sweet Saved Successfully\n";
	add.close();
	system("PAUSE");
	system("CLS");
}
void SEARCH(){
	ifstream search("Sweet.txt");
	cout<<"Enter the name of the Sweet: ";
	string sweetname;
	cin.ignore();
	getline(cin, sweetname);
	string getdata;
	bool checker=false;
	while(getline(search,getdata)){
		istringstream gdata(getdata);
		string name,quantity,price;
		getline(gdata,name,'*');
		getline(gdata,quantity,'*');
		getline(gdata,price);
		if(name==sweetname){
			system("CLS");
			Welcome();
			cout<<"Name\t\t\tQuantity\t\tPrice\n";
			cout<<name<<"\t\t\t"<<quantity<<"\t\t\t"<<price<<endl;
			checker=true;
			system("PAUSE");
			break;
		}
	}
	if(checker==false){
		cout<<"Oops Sweet Name not matched Try again\n";
		sleep(1);
		system("CLS");
		SEARCH();
	}
	system("CLS");
}
void SHOWALL(){
	ifstream show("Sweet.txt");
	Welcome();
	cout<<"NAME\t\t\tQUANTITY\t\tPRICE\n";
	string getdata;
	while(getline(show,getdata)){
		istringstream gdata(getdata);
		string name,quantity,price;
		getline(gdata,name,'*');
		getline(gdata,quantity,'*');
		getline(gdata,price);
			cout<<name<<"\t\t\t"<<quantity<<"\t\t\t"<<price<<endl;
		
	}
	system("PAUSE");
	system("CLS");
}
void Delete(){
	system("CLS");
	Welcome();
	ifstream read("Sweet.txt");
	cout<<"Enter the name of Sweet you want to delete: ";
	string delsweet;
	cin.ignore();
	getline(cin,delsweet);
	bool found=false;
	vector<string>name;
	vector<string>quantity;
	vector<string>price;
	string getsweet;
	while(getline(read,getsweet)){
		istringstream takesweet(getsweet);
		string token;
		getline(takesweet,token, '*');
		name.push_back(token);
		getline(takesweet,token,'*');
		quantity.push_back(token);
		getline(takesweet,token,'*');
		price.push_back(token);
	
	}
	for(int i=0; i<name.size(); i++){
		if(delsweet==name[i]){
			found=true;
			cout<<"Sweet found!\n";
			cout<<"Deleting the sweet\n";
			name.erase(name.begin() + i);
			quantity.erase(quantity.begin() + i);
			price.erase(price.begin() + i);
			ofstream newwrite("Sweet.txt");
			for(int i=0; i<name.size(); i++){
				newwrite<<name[i]<<"*"<<quantity[i]<<"*"<<price[i]<<endl;
			}
			newwrite.close();
			
		}
	}
	if(found==false){
		cout<<"Oops Sweet not found!\n";
		cout<<"Try again\n";
		system("PAUSE");
		Delete();
	}
	cout<<"Deleted successfully\n";
	system("PAUSE");
	system("CLS");
	
}
int main(){
	int choice;
	do{
		Welcome();
		cout<<"1. to add Sweet\n";
		cout<<"2. to search Sweet Record\n";
		cout<<"3. to Show All Sweets\n";
		cout<<"4. to Delete Sweet\n";
		cout<<"5. to Exit\n";
		cout<<"Enter your choice: ";
		cin>>choice;
		switch(choice){
			case 1:
				system("CLS");
				ADD();
				break;
			case 2:
				system("CLS");
				SEARCH();
				break;
			case 3:
				system("CLS");
				SHOWALL();
				break;
			case 4:
				Delete();
				break;
		}
	}
	while(choice!=5);
	return 0;
}
