#include<iostream>
using namespace std;
int main(){
	int courses,total_credit_hrs,local_credit_hrs;
	cout<<"**CPGA CALCULATION PROGRAM ********************_";
	cout<<endl<<endl<<endl;
	cout<<" Program: How many Courses (Credited) you have in this Semester? "<<endl;
	cout<<" You: ";
	cin>>courses;
	string course_name[courses];
	//decalaring an array for details
	float mid_marks[courses],sessionals[courses],final_marks[courses],course_obt[courses],percentage[courses];
	int course_crdt_hrs[courses],course_total[courses];
	bool check = true;
	cout<<"\n Program: How many Credit Hours are there in this Semester?"<<endl;
	cout<<" You: ";
	cin>>total_credit_hrs;
	cout<<endl;
	float course_gpa=0,gpa;
	cout<<" Program: Enter Courses Names, Courses Credit Hours, Courses Total, Mids, Sessionals and Finals Marks Respectively! "<<endl;
	for(int i=0;i<courses;i++){
		
		cout<<"\n Enter Course "<<(i+1)<<" Name : ";
		cin.ignore();
		getline(cin,course_name[i]);
		
		cout<<" Enter "<<course_name[i]<<" Credit Hours: ";
		cin>>course_crdt_hrs[i];
		local_credit_hrs+=course_crdt_hrs[i];
		
		cout<<" Enter "<<course_name[i]<<"'s Total Marks: ";
		cin>>course_total[i];
		
		if(course_total[i]==100 || course_total[i]==50){
		cout<<" Enter "<<course_name[i]<<" Mid Obtained Marks: ";
		cin>>mid_marks[i];
		
		cout<<" Enter "<<course_name[i]<<" Obtained Sessional Marks: ";
		cin>>sessionals[i];
		
		cout<<" Enter "<<course_name[i]<<" Final Obtained Marks: ";
		cin>>final_marks[i];
		
		course_obt[i]=mid_marks[i] + sessionals[i] + final_marks[i];
		percentage[i]=(course_obt[i]/course_total[i])*100;
		
		
		if (course_obt[i]>course_total[i] || course_obt[i]<0){
			cout<<" Incalid this is not wrong information, Please!!! Restart the Program";
			check = false;
			break;
			}
		
		if (course_total[i]==50){
			cout<<" "<<course_name[i]<<" Obtained Marks : "<<course_obt[i]<<endl;
			cout<<" "<<course_name[i]<<" Percentage : "<<percentage[i]<<" %"<<endl; 
		
		if (course_obt[i]>=29.5 && course_obt[i]<31.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 1.67 "<<endl;
			course_gpa+=(1.67*course_crdt_hrs[i]);}
		
		else if(course_obt[i]>=31.5 && course_obt[i]<33.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 2.00 "<<endl;
			course_gpa+=(2*course_crdt_hrs[i]);}
		
		else if(course_obt[i]>=33.5 && course_obt[i]<35.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 2.30 "<<endl;
			course_gpa+=(2.30*course_crdt_hrs[i]);}
		
		else if(course_obt[i]>=35.5 && course_obt[i]<38.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 2.67 "<<endl;
			course_gpa+=(2.67*course_crdt_hrs[i]);}
		
		else if(course_obt[i]>=38.5 && course_obt[i]<41.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 3.00 "<<endl;
			course_gpa+=(3*course_crdt_hrs[i]);}		
				
		else if(course_obt[i]>=41.5 && course_obt[i]<43.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 3.33 "<<endl;
			course_gpa+=(3.33*course_crdt_hrs[i]);}
				
		else if(course_obt[i]>=43.5 && course_obt[i]<45.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 3.67 "<<endl;
			course_gpa+=(3.67*course_crdt_hrs[i]);}
				
		else if(course_obt[i]>=45.5 && course_obt[i]<=50){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 4.00 "<<endl;
			course_gpa+=(4*course_crdt_hrs[i]);}
				
		else if(course_obt[i]>=0 && course_obt[i]<29.5){
			cout<<" You Failed "<<course_name[i]<<" Course"<<endl;
			course_gpa+=(0.00*course_crdt_hrs[i]);}
				
		else 
			cout<<" Invalid Marks"<<endl;	
			}
		else{	
			cout<<" "<<course_name[i] <<" Obtained Marks : "<<course_obt[i]<<endl;
			cout<<" "<<course_name[i]<<" Percentage : "<<percentage[i]<<" %"<<endl; 
		
		if (percentage[i]>=59.5 && percentage[i]<62.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 1.67 "<<endl;
			course_gpa+=(1.67*course_crdt_hrs[i]);}
		
		else if(percentage[i]>=62.5 && percentage[i]<67.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 2.00 "<<endl;
			course_gpa+=(2*course_crdt_hrs[i]);}
		
		else if(percentage[i]>=67.5 && percentage[i]<71.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 2.30 "<<endl;
			course_gpa+=(2.30*course_crdt_hrs[i]);}
				
		else if(percentage[i]>=71.5 && percentage[i]<76.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 2.67 "<<endl;
			course_gpa+=(2.67*course_crdt_hrs[i]);}
				
		else if(percentage[i]>=76.5 && percentage[i]<81.5){
			cout<<" Gpa in "<<course_name[i]<<" is: "<<" 3.00 "<<endl;
			course_gpa+=(3*course_crdt_hrs[i]);}
				
		else if(percentage[i]>=81.5 && percentage[i]<86.5){
		cout<<" Gpa in "<<course_name[i]<<" is: "<<" 3.33 "<<endl;
		course_gpa+=(3.33*course_crdt_hrs[i]);}
				
		else if(percentage[i]>=86.5 && percentage[i]<92.5){
		cout<<" Gpa in "<<course_name[i]<<" is: "<<" 3.67 "<<endl;
		course_gpa+=(3.67*course_crdt_hrs[i]);}
				
		else if(percentage[i]>=92.5 && percentage[i]<=100){
		cout<<" Gpa in "<<course_name[i]<<" is: "<<" 4.00 "<<endl;
		course_gpa+=(4*course_crdt_hrs[i]);}
				
		else if(percentage[i]>=0 && percentage[i]<59.5){
		cout<<" You Failed "<<course_name[i]<<" Course"<<endl;
		course_gpa+=(0*course_crdt_hrs[i]);}
				
		else 
		cout<<" Invalid Marks"<<endl;
			}
	}
		else {
			cout<<" Not IBAIN Grading System"<<endl;
			cout<<" Restart, the Program";
			break;
			}
		}
		if (check == true){
			if(total_credit_hrs==local_credit_hrs){
			gpa = (course_gpa/total_credit_hrs);
			cout<<"\n Your GPA in this Semester is: "<<gpa;}	
			else 
			cout<<" Total Credit Hours are not Equal to Courses Credit Hours\n Pls, Check and Fix the Error";}

return 0;
}
