#include<iostream>
#include<unistd.h>
#include<windows.h>
#include<fstream>
#include<vector>
#include<sstream>
using namespace std;
void Welcome(){
	cout<<"\t\t*******************************\n";
	cout<<"\t\t Phone Book Management System\n";
	cout<<"\t\t*******************************\n";
}
void ADD(){
	Welcome();
	ofstream add("PHONEBOOK.txt", ios::app);
	cout<<"Enter the name of user: ";
	string name;
	cin.ignore();
	getline(cin, name);
	cout<<"Enter the address of user: ";
	string address;
	getline(cin,address);
	cout<<"Enter the number of user: ";
	string number;
	cin.ignore();
	getline(cin,number);
	add<<name<<"*"<<address<<"*"<<"+92"<<number<<endl;
	cout<<"Record Saved Successfully\n";
	add.close();
	system("PAUSE");
	system("CLS");
}
void SEARCH(){
	ifstream search("PHONEBOOK.txt");
	cout<<"Enter the name of the user: ";
	string username;
	cin.ignore();
	getline(cin, username);
	string getdata;
	bool checker=false;
	while(getline(search,getdata)){
		istringstream gdata(getdata);
		string name,number,address;
		getline(gdata,name,'*');
		getline(gdata,address,'*');
		getline(gdata,number);
		if(name==username){
			system("CLS");
			Welcome();
			cout<<"Name\t\tADDRESS\t\tNUMBER\n";
			cout<<name<<"\t\t\t"<<address<<"\t\t\t"<<number<<endl;
			checker=true;
			system("PAUSE");
			break;
		}
	}
	if(checker==false){
		cout<<"Oops Name not matched Try again\n";
		sleep(1);
		system("CLS");
		SEARCH();
	}
	system("CLS");
}
void SHOWALL(){
	ifstream show("PHONEBOOK.txt");
	Welcome();
	cout<<"NAME\t\t\tAddrress\tNumber\n";
	string getdata;
	while(getline(show,getdata)){
		istringstream gdata(getdata);
		string name,address,number;
		getline(gdata,name,'*');
		getline(gdata,address,'*');
		getline(gdata,number);
			cout<<name<<"\t\t\t"<<address<<"\t\t"<<number<<endl;
		
	}
	system("PAUSE");
	system("CLS");
}
void Delete(){
	system("CLS");
	Welcome();
	ifstream read("PHONEBOOK.txt");
	cout<<"Enter the name of User you want to delete: ";
	string delnum;
	cin.ignore();
	getline(cin,delnum);
	bool found=false;
	vector<string>name;
	vector<string>number;
	vector<string>address;
	string getnum;
	while(getline(read,getnum)){
		istringstream takenum(getnum);
		string token;
		getline(takenum,token, '*');
		name.push_back(token);
		getline(takenum,token,'*');
		address.push_back(token);
		getline(takenum,token,'*');
		number.push_back(token);
	
	}
	for(int i=0; i<name.size(); i++){
		if(delnum==name[i]){
			found=true;
			cout<<"Name found!\n";
			cout<<"Deleting the Number\n";
			name.erase(name.begin() + i);
			number.erase(number.begin() + i);
			address.erase(address.begin() + i);
			ofstream newwrite("PHONEBOOK.txt");
			for(int i=0; i<name.size(); i++){
				newwrite<<name[i]<<"*"<<address[i]<<"*"<<"+92"<<number[i]<<endl;
			}
			newwrite.close();
			
		}
	}
	if(found==false){
		cout<<"Oops Number not found!\n";
		cout<<"Try again\n";
		system("PAUSE");
		Delete();
	}
	cout<<"Deleted successfully\n";
	system("PAUSE");
	system("CLS");
	
}
int main(){
	int choice;
	do{
		Welcome();
		cout<<"\t\t1. to add Number\n";
		cout<<"\t\t2. to search Number\n";
		cout<<"\t\t3. to Show All Contacts\n";
		cout<<"\t\t4. to Delete Number\n";
		cout<<"\t\t5. to Exit\n";
		cout<<"\t\tEnter your choice: ";
		cin>>choice;
		switch(choice){
			case 1:
				system("CLS");
				ADD();
				break;
			case 2:
				system("CLS");
				SEARCH();
				break;
			case 3:
				system("CLS");
				SHOWALL();
				break;
			case 4:
				system("CLS");
				Delete();
				break;
		}
	}
	while(choice!=5);
	return 0;
}
