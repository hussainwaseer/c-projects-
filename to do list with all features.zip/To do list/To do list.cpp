#include<iostream>
#include<vector>
#include<unistd.h>
#include<windows.h>
using namespace std;


void welcome(){
	cout<<"*****************\n";
	cout<<"* To do list    *\n";
	cout<<"*****************\n";
}


void add(vector<string> &task){
	system("CLS");
	cout<<"Enter the task you want to add: ";
	cin.ignore();
	string add_task;
	getline(cin,add_task);
	task.push_back(add_task);
	cout<<"Tasks added successfully\n";
	sleep(1);
	system("CLS");
}

void show(vector<string> &task){
	system("CLS");
	welcome();
	cout<<"\nHere are the tasks below: \n";
	for(int i=0; i<task.size(); i++){
			cout<<i+1<<". "<<task[i]<<endl;
			
	}
	cout<<endl;
	system("PAUSE");
	system("CLS");
}

void mark(vector<string> &task){
	system("CLS");
	welcome();
	cout<<"\n Here are the uncompleted tasks: \n";
	for(int i=0; i<task.size(); i++){
		cout<<i<<". "<<task[i]<<endl;
	}
	cout<<"Enter the number of task you completed: ";
	int markascomplete;
	cin>>markascomplete;
	task.erase(task.begin() + markascomplete);
	cout<<"Task deleted successfully!!";
	sleep(1);
	system("CLS");
}

int main(){
	vector<string> task;
	int choice;
	do{
	welcome();
	cout<<"1. to add the task\n";
	cout<<"2. to mark as completed\n";
	cout<<"3. View current tasks\n";
	cout<<"4. to exit\n";
	cout<<"Enter choice: ";
	cin>>choice;
	switch(choice){
	
	case 1:
		add(task);
		break;
	case 2:
		mark(task);
		break;
	case 3:
		show(task);
	}
	}
	while(choice!=4);
	return 0;
}
