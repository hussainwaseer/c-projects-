#include<iostream>
#include<windows.h>
using namespace std;
void encrypt(){
	cin.ignore();
	cout<<"Enter text: ";
	string range;
	getline(cin,range);
	int length=range.length();
	string sipher="";
	for(int i=0; i<length; i++){
		sipher+=int(range[i])+2;
	}
	system("CLS");
	cout<<"\t\t\t************************************\n";
	cout<<"\t\t\t*  Cipher Encryption & Decryption  *\n";
	cout<<"\t\t\t************************************\n";
	cout<<endl<<endl<<"You're Encrypted text is: "<<sipher<<endl;
	cout<<"\n\t\tThanks for using this service:)\n\n";
	system("PAUSE");
}
void decrypt(){
	cin.ignore();
	cout<<"Enter text: ";
	string range;
	getline(cin,range);
	int length=range.length();
	string sipher="";
	for(int i=0; i<length; i++){
		sipher+=int(range[i])-2;
	}
	system("CLS");
	cout<<"\t\t\t************************************\n";
	cout<<"\t\t\t*  Cipher Encryption & Decryption  *\n";
	cout<<"\t\t\t************************************\n";
	cout<<endl<<endl<<"You're Decrypted text is: "<<sipher<<endl;
	cout<<"\n\t\tThanks for using this service:)\n\n";
	system("PAUSE");
}
int main(){
	int choice;
	do{
		cout<<"\t\t\t************************************\n";
		cout<<"\t\t\t*  Cipher Encryption & Decryption  *\n";
		cout<<"\t\t\t************************************\n";
		cout<<"\t\t\t1. for Encryption \n";
		cout<<"\t\t\t2. for Decryption \n";
		cout<<"\t\t\t3. for exit\n";
		cout<<"Enter choice: ";
		cin>>choice;
		switch(choice){
		case 1:
			encrypt();
			system("CLS");
			break;
		case 2:
			decrypt();
			system("CLS");
			break;
	}
	}
	while(choice!=3);
	return 0;
}
