#include<iostream> 
#include<cstdlib> // for generating random numbers to choose random moves
#include<unistd.h> // for sleep function
#include<ctime>    // for seeding the rand function because random function always pick the same move
#include<windows.h>	// for clearing screen
using namespace std;
int main(){
	int choice;
	string input;
	do{
		cout<<"\t\t\t**************************\n";
		cout<<"\t\t\t*    Rock Paper Scissor  *\n";
		cout<<"\t\t\t**************************\n";
		cout<<"1. to Play\n";
		cout<<"2. for Exit\n";
		cout<<"Press any key: ";
		cin>>choice;
		switch(choice){
			case 1:
				system("CLS");
				cout<<"\t\t\t**************************\n";
				cout<<"\t\t\t*   Rock Paper Scissor   *\n";
				cout<<"\t\t\t**************************\n";
				cout<<"p. for Paper\n";
				cout<<"r. for Rock\n";
				cout<<"s. for Scissor\n";
				cout<<"Choose your Move: ";
				cin>>input;
				// Seeding the random system to avoid picking the same move
				srand(static_cast<unsigned int>(time(0)));
				string moves[3]={"rock","paper","scissor"};
				int pickRANDOM=rand() % 3;
				string pickMOVE=moves[pickRANDOM];
				// changing input from p,r,s to paper,rock,scissor because we have to compare with array
				if(input=="r"){
					input="rock";
				}
				else if(input=="s"){
					input="scissor";
				}
				else if(input=="p"){
					input="paper";
				}
				// Game logic for winnning and looosing !!
				if((input=="rock" && pickMOVE=="scissor" )||
				 (input=="paper" && pickMOVE=="rock") ||
				 (input=="scissor" && pickMOVE=="paper")){
				cout<<"\n\t\tYou chose "<<input<<"\t\t computer chose "<<pickMOVE<<endl;
				cout<<"You won!!!!\n";
				cout<<"Screen will be cleared in 5seconds";
				sleep(5);	
				}
				else if(input==pickMOVE){
				cout<<"\n\t\tYou chose "<<input<<"\t\t computer chose "<<pickMOVE<<endl;
				cout<<"The Game is tie:)\n";
				cout<<"Screen will be cleared in 5seconds";
				sleep(5);
				}
				else{
					cout<<"\n\t\tYou chose "<<input<<"\t\t computer chose "<<pickMOVE<<endl;
					cout<<"You lost oops\n";
					cout<<"Screen will be cleared in 5seconds";
					sleep(5);	
		}
				system("CLS");		
		}
	}
	while(choice!=2);
	return 0;
}
