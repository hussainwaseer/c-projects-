#include<iostream>
#include<unistd.h>
#include<windows.h>
using namespace std;
void WELCOME(){
    cout<<"\t\t\t***********************\n";
    cout<<"\t\t\t*        TIMER        *\n";
    cout<<"\t\t\t***********************\n";
}
void TIMER(){
    system("CLS");
    WELCOME();
    double time;
    cout<<"\t\t\tENter the timer in minutes( 1 mintue, 2 minute ): ";
    cin>>time;
    time=60 * time;
    for(int i=time; i>=0; i--){
        system("CLS");
        WELCOME();
        cout<<"\n\n\t\t\tYOu have "<<time<<" seconds left!!\n";
        sleep(1);
        time--;
    }
    system("CLS");
}
int main(){
    int choice;
    do{
        WELCOME();
        cout<<"\t\t\t1. to set timer\n";
        cout<<"\t\t\t2. to exit\n";
        cout<<"Enter your choice: ";
        int choice;
        cin>>choice;
        switch(choice){
            case 1:
                TIMER();
                break;
            case 2:
                cout<<"Exiting!!!";
                break;
        }
    }
    while(choice!=2);
    system("PAUSE");
    return 0;
}
